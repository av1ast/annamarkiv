document.querySelectorAll(".js-ua").forEach(trigger => {
  // pull trigger
  trigger.onclick = () => {
    // langTorigger
    trigger.parentNode.querySelectorAll(".js-ua").forEach(el => {
      el.classList.add("is-active");
    });
    trigger.parentNode.querySelectorAll(".js-en").forEach(el => {
      el.classList.remove("is-active");
    });
    // langContent
    trigger.parentNode.parentNode
      .querySelectorAll(".js-ua-content")
      .forEach(el => {
        el.classList.add("is-active");
      });
    trigger.parentNode.parentNode
      .querySelectorAll(".js-en-content")
      .forEach(el => {
        el.classList.remove("is-active");
      });
  };
});
document.querySelectorAll(".js-en").forEach(trigger => {
  // pull trigger
  trigger.onclick = () => {
    // langTorigger
    trigger.parentNode.querySelectorAll(".js-ua").forEach(el => {
      el.classList.remove("is-active");
    });
    trigger.parentNode.querySelectorAll(".js-en").forEach(el => {
      el.classList.add("is-active");
    });
    // langContent
    trigger.parentNode.parentNode
      .querySelectorAll(".js-ua-content")
      .forEach(el => {
        el.classList.remove("is-active");
      });
    trigger.parentNode.parentNode
      .querySelectorAll(".js-en-content")
      .forEach(el => {
        el.classList.add("is-active");
      });
  };
});